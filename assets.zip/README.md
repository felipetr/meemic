# Meemic


Um boardgame para smartv


Demo: https://meemic.felipetravassos.com/


Version - 0.5
Copyright (c) 2020 Felipe Travassos
